package edu.eci.arsw.threads;

import edu.eci.arsw.blacklistvalidator.HostBlackListsValidator;
import edu.eci.arsw.spamkeywordsdatasource.HostBlacklistsDataSourceFacade;

import java.util.LinkedList;
import java.util.List;

public class BlackListSearchThread extends Thread {
    private int start;
    private int end;
    private String ipAddress;
    private List<Integer> occurrences = new LinkedList<>();
    private int checkCount = 0;

    private final BlackListControl control;

    private HostBlacklistsDataSourceFacade skds = HostBlacklistsDataSourceFacade.getInstance();

    // AGREGADO: Modificamos el constructor para recibir el control
    public BlackListSearchThread(int start, int end, String ipAddress, BlackListControl control) {
        this.start = start;
        this.end = end;
        this.ipAddress = ipAddress;
        this.control = control;
    }

    @Override
    public void run() {
        for (int i = start; i < end; i++) {
            if (control.stopSearch()) {
                break;
            }

            checkCount++;
            if (skds.isInBlackListServer(i, ipAddress)) {
                occurrences.add(i);
                control.reportOccurrence();
            }
        }
    }

    public List<Integer> getOccurrences() {
        return occurrences;
    }

    public int getCheckCount() {
        return checkCount;
    }
}
